import { createContext, useContext, useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from "react-router-dom";

// 1️⃣ تعريف الأنواع (Types)
type User = { username: string };
type AuthContextType = {
  user: User | null;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
};

// 2️⃣ إنشاء الـ Auth Context
const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("auth_user");
    if (stored) {
      try { setUser(JSON.parse(stored)); } catch { localStorage.removeItem("auth_user"); }
    }
    setLoading(false);
  }, []);

  const login = async (username: string, password: string) => {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
      credentials: "include",
    });

    if (res.ok) {
      const newUser = { username };
      setUser(newUser);
      localStorage.setItem("auth_user", JSON.stringify(newUser));
      return;
    }
    const data = await res.json().catch(() => ({ error: "Login failed" }));
    throw new Error(data.error || "Login failed");
  };

  const register = async (username: string, password: string) => {
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
      credentials: "include",
    });
    if (res.ok) return;
    const data = await res.json().catch(() => ({ error: "Register failed" }));
    throw new Error(data.error || "Register failed");
  };

  const logout = () => {
    fetch("/api/auth/logout", { method: "POST", credentials: "include" }).catch(() => {});
    setUser(null);
    localStorage.removeItem("auth_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
};

// 3️⃣ مكون حماية المسارات (Protected Route)
function ProtectedRoute({ children }: { children: JSX.Element }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

// 4️⃣ مكونات الصفحات (Pages Components)
function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [load, setLoad] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoad(true);
    try {
      await login(username, password);
      navigate("/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally { setLoad(false); }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-50 p-4">
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md w-full max-w-sm space-y-4 border">
        <h1 className="text-xl font-bold text-center text-slate-800">Login to Smart Scan</h1>
        <div>
          <label className="text-sm font-medium block mb-1">Username</label>
          <input className="w-full border rounded px-3 py-2 text-sm" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </div>
        <div>
          <label className="text-sm font-medium block mb-1">Password</label>
          <input type="password" className="w-full border rounded px-3 py-2 text-sm" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        {error && <p className="text-xs text-red-500 bg-red-50 p-2 rounded">{error}</p>}
        <button type="submit" disabled={load} className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded text-sm font-medium">
          {load ? "Connecting..." : "Login"}
        </button>
        <p className="text-xs text-center text-slate-500">Don't have an account? <span onClick={() => navigate("/register")} className="text-blue-600 underline cursor-pointer">Register</span></p>
      </form>
    </div>
  );
}

function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [load, setLoad] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoad(true);
    try {
      await register(username, password);
      alert("Account created! Please login.");
      navigate("/login");
    } catch (err: any) {
      setError(err.message);
    } finally { setLoad(false); }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-50 p-4">
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md w-full max-w-sm space-y-4 border">
        <h1 className="text-xl font-bold text-center text-slate-800">Create AI Account</h1>
        <div>
          <label className="text-sm font-medium block mb-1">Username</label>
          <input className="w-full border rounded px-3 py-2 text-sm" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </div>
        <div>
          <label className="text-sm font-medium block mb-1">Password</label>
          <input type="password" className="w-full border rounded px-3 py-2 text-sm" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        {error && <p className="text-xs text-red-500 bg-red-50 p-2 rounded">{error}</p>}
        <button type="submit" disabled={load} className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded text-sm font-medium">
          {load ? "Processing..." : "Register"}
        </button>
        <p className="text-xs text-center text-slate-500">Already have an account? <span onClick={() => navigate("/login")} className="text-blue-600 underline cursor-pointer">Login</span></p>
      </form>
    </div>
  );
}

function Dashboard() {
  const { user, logout } = useAuth();
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 p-6 text-center">
      <div className="p-6 max-w-sm rounded-lg border bg-white shadow-md">
        <h1 className="text-2xl font-bold text-blue-600 mb-2">🎉 Welcome, {user?.username}!</h1>
        <p className="text-slate-500 mb-4 text-sm">Dashboard Active. The system is fully operational and authenticated.</p>
        <button onClick={logout} className="text-sm bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 font-medium transition">
          Logout
        </button>
      </div>
    </div>
  );
}

// 5️⃣ التطبيق الرئيسي وتوزيع المسارات
export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
