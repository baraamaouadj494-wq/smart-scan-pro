import { Router, type IRouter } from "express";
import healthRouter from "./health";
import documentsRouter from "./documents";
import authRouter from "./auth";
import paymentsRouter from "./payments";
import foldersRouter from "./folders";
import vocabularyRouter from "./vocabulary";

const router: IRouter = Router();

router.use(healthRouter);
router.use(documentsRouter);
router.use(authRouter);
router.use(paymentsRouter);
router.use(foldersRouter);
router.use(vocabularyRouter);

export default router;
