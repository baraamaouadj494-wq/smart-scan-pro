import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./auth";

export const foldersTable = pgTable("folders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  color: text("color").default("#6366f1"),
  icon: text("icon").default("folder"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const documentsTable = pgTable("documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => usersTable.id, { onDelete: "cascade" }),
  folderId: integer("folder_id").references(() => foldersTable.id, { onDelete: "set null" }),
  title: text("title").notNull().default("Untitled Document"),
  originalImageUrl: text("original_image_url"),
  processedImageUrl: text("processed_image_url"),
  pdfUrl: text("pdf_url"),
  status: text("status").notNull().default("uploaded"),
  extractedText: text("extracted_text"),
  summary: text("summary"),
  keyPoints: text("key_points"),
  language: text("language").default("en"),
  pageCount: integer("page_count"),
  fileSize: integer("file_size"),
  isFavorite: boolean("is_favorite").notNull().default(false),
  isArchived: boolean("is_archived").notNull().default(false),
  tags: text("tags").default("[]"),
  docType: text("doc_type").default("other"),
  classification: text("classification"),
  extractedEntities: text("extracted_entities"),
  translationCache: text("translation_cache").default("{}"),
  shareToken: text("share_token"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const vocabularyTable = pgTable("vocabulary", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  word: text("word").notNull(),
  translation: text("translation"),
  language: text("language").default("en"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDocumentSchema = createInsertSchema(documentsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documentsTable.$inferSelect;
export type Folder = typeof foldersTable.$inferSelect;
export type VocabWord = typeof vocabularyTable.$inferSelect;
